import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { globalCalendarApi, type CalendarTripSummary } from "../lib/api";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function ymd(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default function GlobalCalendar() {
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(new Date());
  const { data: trips } = useQuery({
    queryKey: ["calendar-mine"],
    queryFn: () => globalCalendarApi.mine().then((r) => r.data),
  });

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstOfMonth = new Date(year, month, 1);
  const startOffset = firstOfMonth.getDay(); // Sunday-first per mockup
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells: (Date | null)[] = [
    ...Array(startOffset).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1)),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  function tripsOnDay(date: Date): CalendarTripSummary[] {
    if (!trips) return [];
    const key = ymd(date);
    return trips.filter((t) => key >= t.startDate.slice(0, 10) && key <= t.endDate.slice(0, 10));
  }

  const monthLabel = cursor.toLocaleDateString("en-GB", { month: "long", year: "numeric" });

  return (
    <main className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl text-ink mb-1">Calendar</h1>
      <p className="font-mono text-xs text-ink/50 mb-6">Every trip you're part of, laid out across the year.</p>

      <div className="border border-paper-dim rounded-md bg-white p-5">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setCursor(new Date(year, month - 1, 1))}
            className="font-mono text-xs px-2 py-1 border border-paper-dim rounded-sm hover:border-route hover:text-route transition-colors"
          >
            ←
          </button>
          <h2 className="font-display text-xl text-ink">{monthLabel}</h2>
          <button
            onClick={() => setCursor(new Date(year, month + 1, 1))}
            className="font-mono text-xs px-2 py-1 border border-paper-dim rounded-sm hover:border-route hover:text-route transition-colors"
          >
            →
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-1">
          {WEEKDAYS.map((w) => (
            <div key={w} className="font-mono text-[10px] uppercase tracking-widest text-ink/40 text-center py-1">
              {w}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {cells.map((date, i) => {
            if (!date) return <div key={i} className="min-h-[64px]" />;
            const dayTrips = tripsOnDay(date);
            return (
              <div key={i} className="min-h-[64px] border border-paper-dim rounded-sm p-1 flex flex-col gap-0.5">
                <span className="font-mono text-[10px] text-ink/50">{date.getDate()}</span>
                {dayTrips.slice(0, 2).map((t) => (
                  <button
                    key={t.id}
                    onClick={() => navigate(`/trips/${t.id}`)}
                    title={t.title}
                    className="font-mono text-[9px] bg-route/15 text-route rounded-sm px-1 py-0.5 truncate text-left hover:bg-route/25 transition-colors"
                  >
                    {t.title}
                  </button>
                ))}
                {dayTrips.length > 2 && (
                  <span className="font-mono text-[9px] text-ink/40">+{dayTrips.length - 2} more</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
}
