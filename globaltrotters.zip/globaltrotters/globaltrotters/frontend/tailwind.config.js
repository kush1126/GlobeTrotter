/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0F172A",
          light: "#1E293B",
          muted: "#475569",
          faint: "#94A3B8",
        },
        paper: {
          DEFAULT: "#F9F8F5",
          pure: "#FFFFFF",
          dim: "#E8E4DA",
          dark: "#D8D2C2",
        },
        route: {
          DEFAULT: "#0F766E",
          light: "#14B8A6",
          dark: "#115E59",
          subtle: "#F0FDFA",
        },
        ochre: {
          DEFAULT: "#D97706",
          light: "#F59E0B",
          subtle: "#FEF3C7",
        },
        rust: {
          DEFAULT: "#E11D48",
          dark: "#BE123C",
          subtle: "#FFE4E6",
        },
        indigo: {
          brand: "#4338CA",
          subtle: "#EEF2FF",
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', "Georgia", "serif"],
        heading: ['"Outfit"', '"Plus Jakarta Sans"', "sans-serif"],
        body: ['"Plus Jakarta Sans"', "sans-serif"],
        mono: ['"JetBrains Mono"', '"IBM Plex Mono"', "monospace"],
      },
      boxShadow: {
        soft: "0 2px 10px -2px rgba(15, 23, 42, 0.05), 0 1px 4px -1px rgba(15, 23, 42, 0.03)",
        card: "0 4px 20px -2px rgba(15, 23, 42, 0.08), 0 2px 6px -1px rgba(15, 23, 42, 0.04)",
        lift: "0 12px 28px -4px rgba(15, 23, 42, 0.12), 0 4px 10px -2px rgba(15, 23, 42, 0.06)",
        glow: "0 0 24px -4px rgba(20, 184, 166, 0.35)",
      },
      backgroundImage: {
        perforate: "radial-gradient(circle, transparent 4px, #F9F8F5 4.5px)",
      },
    },
  },
  plugins: [],
};
